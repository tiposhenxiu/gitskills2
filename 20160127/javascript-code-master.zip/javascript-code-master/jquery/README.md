# ## 优秀的jQuery库插件 ## #

**jQuery++**
jQuery++ 在 jQuery 1.7.x 的基础上增加了一些 DOM 助手方法，目的是提供 jQuery 所不支持的功能，包括 Cookie 操作、DOM Range 和表单处理 [官方地址](http://jquerypp.com/ "http://jquerypp.com/")

**jQuery Form**  
不错的ajax 表单提交处理 [官方地址](http://www.malsup.com/jquery/form/ "http://www.malsup.com/jquery/form/")

**qTIp**  
qTip2 精致的jQuery提示信息插件 [官方地址](http://qtip2.com/ "qTip2 官方地址")


