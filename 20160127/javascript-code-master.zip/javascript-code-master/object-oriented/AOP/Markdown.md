AOP

[Javascript AOP的实现](http://www.cnblogs.com/rubylouvre/archive/2009/08/08/1541578.html "javascript Aop实现")  

[AOP改善代码](http://www.alloyteam.com/2013/08/yong-aop-gai-shan-javascript-dai-ma/ "AOP 改善代码")