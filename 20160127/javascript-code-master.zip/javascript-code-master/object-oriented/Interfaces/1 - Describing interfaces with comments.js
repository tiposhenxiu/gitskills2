/*

interface Composite {
    function add(child);
    function remove(child);
    function getChild(index);
}

interface FormItem {
    function save();
}

*/

var CompositeForm = function(id, method, action) { // implements Composite, FormItem
    //todo
};

// Implement the Composite interface.

CompositeForm.prototype.add = function(child) {
    //todo
};
CompositeForm.prototype.remove = function(child) {
    //todo
};
CompositeForm.prototype.getChild = function(index) {
    //todo
};

// Implement the FormItem interface.

CompositeForm.prototype.save = function() {
    //todo
};
