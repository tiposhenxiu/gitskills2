// Book(isbn, title, author)
var theHobbit = new Book('0-395-07122-4', 'The Hobbit', 'J. R. R. Tolkein');
theHobbit.display(); // Outputs the data by creating and populating an HTML element.
