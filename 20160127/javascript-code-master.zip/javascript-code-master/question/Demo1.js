/**
 * Created with JetBrains WebStorm.
 * User: cwwu
 * Date: 13-8-8
 * Time: 下午5:40
 * 方法前面加操作符号
 */

+function  fun(){

}
-function  fun(){

}
!function  fun(){

}