### Deploying Node applications with Docker and Codeship

**This is a work in progress!**