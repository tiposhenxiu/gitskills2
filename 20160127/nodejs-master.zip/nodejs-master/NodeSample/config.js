exports.debug = true;
exports.port = 3000;
exports.email = 'wchaowu@gmail.com';
exports.site_name = 'Scott TODO';
exports.site_desc = 'Very simple todo, demo for connect web dev.';
exports.session_secret = 'scott todo session secret';
exports.root=__dirname;
// mongoDb connection 
exports.db = 'mongodb://127.0.0.1:27017/scott_dev';
