/**
 * Created with JetBrains WebStorm.
 * User: cwwu
 * Date: 13-7-19
 * Time: 下午4:42
 * To change this template use File | Settings | File Templates.
 */


var fileOperator = {};
var fileOperator = {
    refresh:function(){

    },
    newDirectory:function(){

    },
    newFile:function(){

    },
    del:function(){

    },
    cut:function(){

    },
    copy:function(){

    },
    paste:function(){

    },
    zipFile:function(){

    },
    unZipFile:function(){

    },
    downLoad:function(){

    },
    uploadFile:function(){

    },
    ckAllFile:function(){

}

}
fi