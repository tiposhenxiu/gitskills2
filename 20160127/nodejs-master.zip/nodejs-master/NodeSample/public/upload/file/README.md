# NodeSample

Node.js+express.js+mongoose+ejs+monogdb做的
此Demo只要有javascript的基础就可以看懂。
框架用的MVC方式。
