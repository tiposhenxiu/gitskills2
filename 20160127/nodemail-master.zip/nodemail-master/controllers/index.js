module.exports = function(req, res) {
  res.partial('../README.md');
};
