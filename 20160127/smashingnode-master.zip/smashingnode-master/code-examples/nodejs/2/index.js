var a = require('./module_a');
console.log(a.name);
console.log(a.data);
console.log(a.getPrivate());
