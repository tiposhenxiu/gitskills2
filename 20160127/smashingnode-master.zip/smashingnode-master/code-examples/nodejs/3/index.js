var Person = require('./person');
var john = new Person('john');
john.talk();
