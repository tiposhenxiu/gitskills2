
module.exports = function (str) {
  return str;
}
