
// if node
process.exit(1);
// end

console.log('browser and node');
