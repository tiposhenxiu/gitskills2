describe('my tests', function () {
  it('should not throw', function () {
    expect(1 + 1).to.be(2);
  });
});
