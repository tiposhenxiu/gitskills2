console.log(process.argv.slice(2));
