process.stdout.write('Hello world');
