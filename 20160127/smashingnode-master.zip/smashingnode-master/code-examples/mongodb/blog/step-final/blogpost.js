
/**
 * Module dependencies.
 */

var mongoose = require('mongoose')
  , Schema = mongoose.Schema

/**
 * Module exports.
 */

var BlogPost = module.exports = new Schema({
    

});
