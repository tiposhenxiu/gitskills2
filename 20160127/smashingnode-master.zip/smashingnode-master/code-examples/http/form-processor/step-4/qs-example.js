
console.log(require('querystring').parse('name=Guillermo'));
console.log(require('querystring').parse('q=guillermo+rauch'));
