require('colors');
console.log('smashing node'.rainbow);

