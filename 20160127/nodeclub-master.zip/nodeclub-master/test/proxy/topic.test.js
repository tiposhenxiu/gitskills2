var Topic = require('../../proxy/topic');
var support = require('../support/support');
var should = require('should');

describe('test/proxy/topic.test.js', function () {
});
