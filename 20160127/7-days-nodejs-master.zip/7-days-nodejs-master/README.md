七天学会NodeJS
=============

这是一本NodeJS新手入门教程，涵盖了使用NodeJS开发各种程序所必要的知识，请点击以下链接阅读。

>	[http://nqdeng.github.io/7-days-nodejs/](http://nqdeng.github.io/7-days-nodejs/)

另外，如果愿意协助完善这篇教程的话，您可能需要用到[天书](https://github.com/nqdeng/tianshu)这个小工具。
