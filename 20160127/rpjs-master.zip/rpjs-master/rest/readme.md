# Chat Application

* Parse.com REST API
* jQuery
* Twitter Bootstrap

All logic is in the app.js. Change parseID and parseKey to _your_ values.
